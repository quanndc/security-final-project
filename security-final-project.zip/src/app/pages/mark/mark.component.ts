import { Component } from '@angular/core';

@Component({
  selector: 'app-mark',
  standalone: true,
  imports: [],
  templateUrl: './mark.component.html',
  styleUrl: './mark.component.scss'
})
export class MarkComponent {

}
