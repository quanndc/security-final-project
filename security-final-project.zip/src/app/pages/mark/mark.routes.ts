import {Routes} from '@angular/router';
import {MarkComponent} from './mark.component';

export const MARK_ROUTES: Routes = [
  {
    path: '',
    component: MarkComponent
  }
];
