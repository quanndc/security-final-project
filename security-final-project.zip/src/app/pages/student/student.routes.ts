import {Routes} from '@angular/router';
import {StudentComponent} from './student.component';

export const STUDENT_ROUTES: Routes = [
  {
    path: '',
    component: StudentComponent
  }
];
