import {Routes} from '@angular/router';
import {ClassComponent} from './class.component';

export const CLASS_ROUTES: Routes = [
  {
    path: '',
    component: ClassComponent
  }
];
