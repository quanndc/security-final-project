import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-QMCRGEY7.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-YXCTAH5B.js";
import "./chunk-LCN2NJQ2.js";
import "./chunk-TA77IE7N.js";
import "./chunk-VSWBU2LU.js";
import "./chunk-S5GDUUVE.js";
import "./chunk-5AGTDSY4.js";
import "./chunk-X27HKYHI.js";
import "./chunk-CN7NKDCL.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-XG25NGES.js";
import "./chunk-FGTGOGG3.js";
import "./chunk-7GPR7GZV.js";
import "./chunk-TUUKO4V4.js";
import "./chunk-J5VREHIK.js";
import "./chunk-I6S27ITP.js";
import "./chunk-NTERNHDG.js";
import "./chunk-5K356HEJ.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
