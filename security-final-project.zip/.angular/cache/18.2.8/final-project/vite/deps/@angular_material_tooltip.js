import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-2JBQIJ5K.js";
import "./chunk-TA77IE7N.js";
import "./chunk-VSWBU2LU.js";
import "./chunk-S5GDUUVE.js";
import "./chunk-5AGTDSY4.js";
import "./chunk-X27HKYHI.js";
import "./chunk-XG25NGES.js";
import "./chunk-FGTGOGG3.js";
import "./chunk-7GPR7GZV.js";
import "./chunk-TUUKO4V4.js";
import "./chunk-J5VREHIK.js";
import "./chunk-I6S27ITP.js";
import "./chunk-NTERNHDG.js";
import "./chunk-5K356HEJ.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
//# sourceMappingURL=@angular_material_tooltip.js.map
