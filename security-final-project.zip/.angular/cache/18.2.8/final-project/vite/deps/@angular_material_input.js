import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-QGE3BJYG.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-YXCTAH5B.js";
import "./chunk-LCN2NJQ2.js";
import "./chunk-TA77IE7N.js";
import "./chunk-CN7NKDCL.js";
import "./chunk-XG25NGES.js";
import "./chunk-FGTGOGG3.js";
import "./chunk-7GPR7GZV.js";
import "./chunk-TUUKO4V4.js";
import "./chunk-J5VREHIK.js";
import "./chunk-I6S27ITP.js";
import "./chunk-NTERNHDG.js";
import "./chunk-5K356HEJ.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
